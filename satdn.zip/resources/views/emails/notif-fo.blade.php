<!DOCTYPE html>
<html>
<head>
    <title>siap.bulukumbakab.go.id</title>
</head>
<body>
    <h3>{{ $details['title'] }}</h3>
    <p>{{ $details['body'] }}</p>
   
    <p>Dikirim oleh sistem</p>
</body>
</html>