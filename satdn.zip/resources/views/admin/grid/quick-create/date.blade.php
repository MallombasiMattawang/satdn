<div class="input-group input-group-sm">
    <input style="width: 125px;" {!! $attributes !!} placeholder="{{ $label }}" />
</div>