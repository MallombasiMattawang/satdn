<?php

namespace App\Http\Controllers;

use App\Models\AdminUser;
use App\Models\PemegangIzin;
use App\Models\TranSatdn;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class IzinEdarController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    public function index()
    {
        $data = PemegangIzin::where('user_id', Auth::user()->id)->latest()->paginate(20);
        return view('user-page.izin-edar.index', [
            'data' => $data
        ]);
    }

    public function form($id)
    {
        $data = PemegangIzin::findOrFail($id);
        if (Auth::user()->id != $data->user_id) {
            return redirect('/home');
        }

        $admin_teknis = AdminUser::where('id', '>', '25')->get();
        return view('user-page.izin-edar.create', [
            'data' => $data,
            'admin_teknis' => $admin_teknis
        ]);
    }

    public function store(Request $request)
    {
        $data = PemegangIzin::findOrFail($request->pemegang_izin_id);
        if (Auth::user()->id != $data->user_id) {
            return redirect('/home');
        }
        $request->validate([
            'no_permohonan_angkut' => 'required',
            'no_satdn_asal' => 'required',
            'nama_penerima' => 'required',
            'telepon_penerima' => 'required',
            'alamat_lengkap_penerima' => 'required',
            'alat_angkut' => 'required',
            'dari' => 'required',
            'ke' => 'required',
            'admin_teknis' => 'required',
            'jumlah_kirim' => 'required|numeric|max:' . $data->kuota - $data->kuota_digunakan . '',
        ],[
            'required' => ':attribute harus diisi',
            'jumlah_kirim.max' => 'Jumlah kirim tidak boleh melebihi kuota (' . $data->kuota - $data->kuota_digunakan . ')',
            'numeric' => ':attribute harus berupa angka '
        ]);
        $awal = 'KSDA';
        $lastId = TranSatdn::max('id');
        $invoice = sprintf("%03s",  abs($lastId + 1) . '/' . $awal . '/' . date('n') . '/' . date('Y'));

        $progresDocument = TranSatdn::create([
            'pemegang_izin_id' => $data->id,
            'no_permohonan_angkut' => $request->no_permohonan_angkut,
            'no_satdn_asal' => $request->no_satdn_asal,
            'nama_penerima' => $request->nama_penerima,
            'telepon_penerima' => $request->telepon_penerima,
            'fax_penerima' => $request->fax_penerima,
            'alamat_lengkap_penerima' => $request->alamat_lengkap_penerima,
            'alat_angkut' => $request->alat_angkut,
            'dari' => $request->dari,
            'ke' => $request->ke,
            'jumlah_kirim' => $request->jumlah_kirim,
            'jenis_tsl' => $data->jenis_tsl,
            'satuan' => $data->satuan,
            'invoice' => $invoice,
            'admin_teknis' => $request->admin_teknis,
        ]);
        $progresDocument->save();

        PemegangIzin::where("id",  $data->id,)
            ->update([
                'kuota_digunakan' => $data->kuota_digunakan + $request->jumlah_kirim,
                'kuota_sisa' => $data->kuota - $request->jumlah_kirim,
            ]);

            return redirect()->back()->with('message', 'Permohonan Sats-DN Berhasil Dikirim');;
    }
}
