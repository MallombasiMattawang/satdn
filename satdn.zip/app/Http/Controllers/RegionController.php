<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class regionController extends Controller
{
    //
}
