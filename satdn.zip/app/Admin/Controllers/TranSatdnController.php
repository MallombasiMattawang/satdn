<?php

namespace App\Admin\Controllers;

use App\Models\TranSatdn;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use Encore\Admin\Layout\Content;

class TranSatdnController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'SATS-DN PEMEGANG IZIN';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function all($tipe, Content $content)
    {
        $grid = new Grid(new TranSatdn());

        $grid->column('invoice', __('Invoice'));
        $grid->column('pemegangIzin.nama_perusahaan', __('Pemegang izin'));
        $grid->column('no_permohonan_angkut', __('No permohonan angkut'));
        $grid->column('alat_angkut', __('Alat angkut'));
        $grid->column('dari', __('Dari'));
        $grid->column('ke', __('Ke'));
        $grid->column('jenis_tsl', __('Jenis tsl'));
        $grid->column('satuan', __('Satuan'));
        $grid->column('jumlah_kirim', __('Jumlah kirim'));
        $grid->column('posisi', __('Posisi'));
        $grid->column('status', __('Status'));
        $grid->column('status_ket', __('Status ket'));

        if ($tipe == 'masuk') {
            $header = 'Masuk';
            $grid->model()->whereNull('status');
        }
        if ($tipe == 'keluar') {
            $header = 'Selesai';
            $grid->model()->where('status', 'SELESAI');
            $grid->column('dikeluarkan_di', __('Dikeluarkan di'));
            $grid->column('tgl_satdn_mulai', __('Tgl satdn mulai'));
            $grid->column('tgl_satdn_habis', __('Tgl satdn habis'));
        }
        if ($tipe == 'ditolak') {
            $header = 'Ditolak';
            $grid->model()->where('status', 'DITOLAK');
        }

        $grid->paginate(50);
        $grid->disableCreateButton();

        return $content
            ->header('Permohonan SATS-DN Pemegang Izin ' .$header)
            // ->description('Data DTDC')
            ->body(view('admin.modules.tran-satdn.all'))
            ->body($grid);
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(TranSatdn::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('pemegang_izin_id', __('Pemegang izin id'));
        $show->field('invoice', __('Invoice'));
        $show->field('no_permohonan_angkut', __('No permohonan angkut'));
        $show->field('no_satdn_asal', __('No satdn asal'));
        $show->field('nama_penerima', __('Nama penerima'));
        $show->field('telepon_penerima', __('Telepon penerima'));
        $show->field('fax_penerima', __('Fax penerima'));
        $show->field('alamat_lengkap_penerima', __('Alamat lengkap penerima'));
        $show->field('alat_angkut', __('Alat angkut'));
        $show->field('dari', __('Dari'));
        $show->field('ke', __('Ke'));
        $show->field('jenis_tsl', __('Jenis tsl'));
        $show->field('satuan', __('Satuan'));
        $show->field('jumlah_kirim', __('Jumlah kirim'));
        $show->field('posisi', __('Posisi'));
        $show->field('status', __('Status'));
        $show->field('status_ket', __('Status ket'));
        $show->field('admin_teknis', __('Admin teknis'));
        $show->field('date_verified_teknis', __('Date verified teknis'));
        $show->field('verifikator_teknis', __('Verifikator teknis'));
        $show->field('ket_teknis', __('Ket teknis'));
        $show->field('no_bap', __('No bap'));
        $show->field('file_bap', __('File bap'));
        $show->field('no_spt', __('No spt'));
        $show->field('file_spt', __('File spt'));
        $show->field('no_satdn', __('No satdn'));
        $show->field('dikeluarkan_di', __('Dikeluarkan di'));
        $show->field('tgl_satdn_mulai', __('Tgl satdn mulai'));
        $show->field('tgl_satdn_habis', __('Tgl satdn habis'));
        $show->field('pj_ttd', __('Pj ttd'));
        $show->field('pj_nip', __('Pj nip'));
        $show->field('updated_at', __('Updated at'));
        $show->field('created_at', __('Created at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new TranSatdn());

        $form->number('pemegang_izin_id', __('Pemegang izin id'));
        $form->text('invoice', __('Invoice'));
        $form->text('no_permohonan_angkut', __('No permohonan angkut'));
        $form->text('no_satdn_asal', __('No satdn asal'));
        $form->text('nama_penerima', __('Nama penerima'));
        $form->text('telepon_penerima', __('Telepon penerima'));
        $form->text('fax_penerima', __('Fax penerima'));
        $form->text('alamat_lengkap_penerima', __('Alamat lengkap penerima'));
        $form->text('alat_angkut', __('Alat angkut'));
        $form->text('dari', __('Dari'));
        $form->text('ke', __('Ke'));
        $form->text('jenis_tsl', __('Jenis tsl'));
        $form->text('satuan', __('Satuan'));
        $form->number('jumlah_kirim', __('Jumlah kirim'));
        $form->text('posisi', __('Posisi'));
        $form->text('status', __('Status'));
        $form->textarea('status_ket', __('Status ket'));
        $form->number('admin_teknis', __('Admin teknis'));
        $form->datetime('date_verified_teknis', __('Date verified teknis'))->default(date('Y-m-d H:i:s'));
        $form->text('verifikator_teknis', __('Verifikator teknis'));
        $form->textarea('ket_teknis', __('Ket teknis'));
        $form->text('no_bap', __('No bap'));
        $form->text('file_bap', __('File bap'));
        $form->text('no_spt', __('No spt'));
        $form->text('file_spt', __('File spt'));
        $form->text('no_satdn', __('No satdn'));
        $form->text('dikeluarkan_di', __('Dikeluarkan di'));
        $form->date('tgl_satdn_mulai', __('Tgl satdn mulai'))->default(date('Y-m-d'));
        $form->date('tgl_satdn_habis', __('Tgl satdn habis'))->default(date('Y-m-d'));
        $form->text('pj_ttd', __('Pj ttd'));
        $form->text('pj_nip', __('Pj nip'));

        return $form;
    }
}
