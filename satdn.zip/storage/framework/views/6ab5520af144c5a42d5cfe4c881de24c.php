<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <title>Dashboard - User</title>

    <link href="<?php echo e(asset('assets/user-page/css/styles.css'), false); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/user-page/rating/css/star-rating.css'), false); ?>" rel="stylesheet" type="text/css">
    
    <script data-search-pseudo-elements="" defer=""
        src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.28.0/feather.min.js" crossorigin="anonymous">
    </script>

    <style>
        /* untuk menghilangkan spinner  */
        .spinner {
            display: none;
        }

        .displaynone {
            display: none;
        }

    </style>
</head>

<body class="nav-fixed">
    <?php $__env->startSection('header'); ?>
        <?php echo $__env->make('layouts.user-page.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $__env->startSection('sidenav'); ?>
                <?php echo $__env->make('layouts.user-page.inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldSection(); ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <?php $__env->startSection('footer'); ?>
                <?php echo $__env->make('layouts.user-page.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldSection(); ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>   

    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/components/prism-core.min.js" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/plugins/autoloader/prism-autoloader.min.js"
        crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(asset('assets/user-page/js/scripts.js'), false); ?>"></script>
    <script src="<?php echo e(asset('assets/user-page/js/custom.js'), false); ?>"></script>   


    <?php echo $__env->yieldContent('footer_scripts'); ?>


</body>

</html>
<?php /**PATH C:\laragon\www\satdn\resources\views/layouts/user-page/app.blade.php ENDPATH**/ ?>