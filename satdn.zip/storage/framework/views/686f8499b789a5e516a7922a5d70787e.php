<?php $__env->startSection('content'); ?>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container-xl px-4">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i data-feather="user"></i></div>
                            History Layanan
                        </h1>

                    </div>

                </div>
            </div>
        </div>
    </header>
    <div class="container-xl px-4 mt-n10">
        <div class="card">
            <div class="card-body px-0">
                <?php $__empty_1 = true; $__currentLoopData = $historyServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex align-items-center justify-content-between px-4">
                        <div class="d-flex align-items-center">

                            <div class="ms-4">
                                <div class="small"><?php echo e($item->no_invoice, false); ?> - <?php echo e($item->service->name, false); ?></div>
                                <div class="text-xs text-muted"><?php echo e($item->created_at_difference(), false); ?>

                                    <?php if($item->status == 'VERIFIKASI DOKUMEN DITOLAK' || $item->status == 'VERIFIKASI TEKNIS DITOLAK'): ?>
                                        <span class="badge bg-danger text-white ">Ditolak</span>
                                    <?php elseif($item->status == 'UPLOAD DOC.'): ?>
                                        <span class="badge bg-info text-white ">Upload Doc</span>

                                    <?php elseif($item->date_end_progres != null): ?>
                                        <span class="badge bg-success text-white ">Selesai</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-white ">Verifikasi</span>
                                    <?php endif; ?>


                                </div>

                            </div>
                        </div>
                        <div class="ms-4 small">
                            <?php if($item->status == 'UPLOAD DOC.'): ?>
                                <a href="<?php echo e(route('getDocument', $item->id), false); ?>" class="btn btn-info"> <i
                                        data-feather="upload"></i> </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('getVerified', $item->id), false); ?>" class="btn btn-primary"> <i
                                        data-feather="eye"></i></a>
                            <?php endif; ?>


                        </div>
                    </div>
                    <hr />

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-info" style="margin: 10px">
                        Belum ada permohonan izin
                    </div>



                <?php endif; ?>

                <div class="table-responsive">
                    <?php echo e($historyServices->links('vendor.pagination.custom'), false); ?>

                </div>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-page.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\satdn\resources\views/user-page/history-page.blade.php ENDPATH**/ ?>