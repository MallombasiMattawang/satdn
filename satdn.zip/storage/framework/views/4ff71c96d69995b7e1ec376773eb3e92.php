<?php $__env->startSection('content'); ?>
<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i data-feather="user"></i>

                        </div>
                         Layanan Perizinan
                    </h1>

                </div>

            </div>
        </div>
    </div>
</header>
    <div class="container-xl px-4 mt-n10">
        <div class="card">
            <div class="card-body">
                <div class="row" >
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status'), false); ?>

                        </div>
                    <?php endif; ?>
                    <!-- Navbar Search-->
                    <form class=" d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                        <div class="input-group">
                            <input class="form-control form-search" type="text" placeholder="Cari layanan..."
                                aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                            <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                        </div>
                        <br>
                    </form>
                    <div class="row div-search" style="margin: auto !important">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-md-6 mb-2">
                                <a class="card lift lift-sm h-100" href="<?php echo e(route('getService', $service->id), false); ?>">
                                    <div class="card-body">
                                        <p class="text-blue mb-2 text-center" >

                                            <?php echo e($service->name, false); ?>

                                        </p>

                                    </div>

                                </a>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                </div>
            </div>

        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-page.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\satdn\resources\views/user-page/home.blade.php ENDPATH**/ ?>