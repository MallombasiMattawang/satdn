<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-6 order-md-2">
                    <img src="<?php echo e(asset('assets/auth-page/images/splash2.png'), false); ?>" alt="Image"
                        class="img-fluid">
                </div>
                <div class="col-md-6 contents">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="mb-4">
                                <h3><strong>BBKSDA-ONLINE</strong></h3>
                                <p class="mb-4">LOGIN LAYANAN BBKSDA SULAWESI SELATAN</p>
                            </div>
                            <form class="form-prevent" method="POST" action="<?php echo e(route('login'), false); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group first">
                                    <label for="email">E-Mail</label>
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email" value="<?php echo e(old('email'), false); ?>" required autocomplete="email" autofocus>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message, false); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group last mb-4">
                                    <label for="password">Password</label>
                                    <input id="password" type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                        required autocomplete="current-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message, false); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="d-flex mb-5 align-items-center">
                                    <label class="control control--checkbox mb-0"><span
                                            class="caption"><?php echo e(__('Remember Me'), false); ?></span>
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                            <?php echo e(old('remember') ? 'checked' : '', false); ?>>
                                        <div class="control__indicator"></div>
                                    </label>
                                    <?php if(Route::has('password.request')): ?>
                                        <span class="ml-auto">
                                            <a class="forgot-pass" href="<?php echo e(route('password.request'), false); ?>">
                                                <?php echo e(__('Forgot Password?'), false); ?>

                                            </a>
                                        </span>
                                    <?php endif; ?>

                                </div>

                                <button type="submit" class="btn text-white btn-block btn-warning button-prevent">
                                    <div class="spinner"><i role="status" class="spinner-border spinner-border-sm"></i> Loading... </div>
                                    <div class="hide-text">Log-in</div>
                                </button>



                                <span class="d-block text-left my-4 text-muted"> Atau Buat akun di <a class="" href="<?php echo e(route('register'), false); ?>"><?php echo e(__('Register'), false); ?></a></span>


                            </form>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\satdn\resources\views/auth/login.blade.php ENDPATH**/ ?>