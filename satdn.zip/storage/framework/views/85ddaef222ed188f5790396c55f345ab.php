<?php $__env->startSection('content'); ?>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container-xl px-4">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i data-feather="user"></i></div>
                            Daftar Izin Peredaran Saya
                        </h1>

                    </div>

                </div>
            </div>
        </div>
    </header>
    <div class="container-xl px-4 mt-n10">
        <div class="card">
            <div class="card-body px-0">
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex align-items-center justify-content-between px-4">
                        <div class="d-flex align-items-center">

                            <div class="ms-4">
                                <div class="small"><?php echo e($item->nama_perusahaan, false); ?> - <?php echo e($item->jenis_tsl, false); ?></div>
                                <div class="text-xs text-muted"><?php echo e($item->no_sk_oss, false); ?>

                                    <br>
                                    <?php if($item->active == 'N'): ?>
                                        <span class="badge bg-danger text-white ">Non Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-success text-white ">Active</span>
                                    <?php endif; ?>
                                    <span class="badge bg-primary text-white ">Expired : <?php echo e(tgl_indo($item->tgl_habis_sk), false); ?></span>
                                    <span class="badge bg-info text-white ">Total Kuota : <?php echo e($item->kuota, false); ?></span>
                                    <span class="badge bg-black text-white ">Kuota digunakan : <?php echo e($item->kuota_digunakan, false); ?></span>
                                    <span class="badge bg-orange text-white ">Sisa Kuota : <?php echo e($item->kuota_sisa, false); ?></span>

                                </div>

                            </div>
                        </div>
                        <div class="ms-4 small">


                                <a href="<?php echo e(route('izin.edar.create', [$item->id]), false); ?>" class="btn btn-yellow"> Buat SATSDN</a>



                        </div>
                    </div>
                    <hr />

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-info" style="margin: 10px">
                        Belum memiliki izin edar TSL
                    </div>



                <?php endif; ?>

                <div class="table-responsive">
                    <?php echo e($data->links('vendor.pagination.custom'), false); ?>

                </div>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-page.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\satdn\resources\views/user-page/izin-edar/index.blade.php ENDPATH**/ ?>