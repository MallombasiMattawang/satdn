<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

    <title><?php echo e(config('app.name', 'SIMAP-ONLINE'), false); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js'), false); ?>" defer></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth-page/fonts/icomoon/style.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth-page/css/owl.carousel.min.css'), false); ?>">

    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth-page/css/bootstrap.min.css'), false); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/auth-page/css/style.css'), false); ?>" rel="stylesheet">
    <style>
        /* untuk menghilangkan spinner  */
        .spinner {
            display: none;
        }

    </style>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    

    <script src="<?php echo e(asset('assets/auth-page/js/main.js'), false); ?>"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <script>
        // jika form-prevent disubmit maka disable button-prevent dan tampilkan spinner
        (function() {
            $('.form-prevent').on('submit', function() {
                $('.button-prevent').attr('disabled', 'true');
                $('.spinner').show();
                $('.hide-text').hide();
            })
        })();
    </script>

</body>

</html>
<?php /**PATH C:\laragon\www\satdn\resources\views/layouts/auth.blade.php ENDPATH**/ ?>