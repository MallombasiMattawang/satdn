<nav class="sidenav shadow-right sidenav-light">
    <div class="sidenav-header text-center" style="padding:10px;">
        <img class="img-fluid" src="<?php echo e(asset('assets/img/bksda-sulsel-logo.jpg'), false); ?>" alt="" width="100">
    </div>
    <div class="sidenav-menu">
        <div class="nav accordion" id="accordionSidenav">

            <!-- Sidenav Menu Heading (menu layanan)-->
            <div class="sidenav-menu-heading">Menu Layanan</div>
            <a class="nav-link" href="<?php echo e(route('home'), false); ?>">
                <div class="nav-link-icon"><i data-feather="grid"></i></div>
                Daftar Perizinan
            </a>

            <!-- Sidenav Heading (Custom)-->
            <div class="sidenav-menu-heading">Perizinan saya</div>
            <!-- Sidenav Accordion (Pages)-->
            <a class="nav-link" href="<?php echo e(route('izin.edar'), false); ?>">
                <div class="nav-link-icon"><i data-feather="filter"></i></div>
                Izin Peredaran TSL
            </a>
            <a class="nav-link" href="<?php echo e(route('history'), false); ?>">
                <div class="nav-link-icon"><i data-feather="filter"></i></div>
                Tracking Izin
            </a>


        </div>
    </div>
    <!-- Sidenav Footer-->
    <div class="sidenav-footer">
        <div class="sidenav-footer-content">
            <div class="sidenav-footer-subtitle">Logged in as:</div>
            <div class="sidenav-footer-title"><?php echo e(Auth::user()->name, false); ?></div>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\satdn\resources\views/layouts/user-page/inc/sidenav.blade.php ENDPATH**/ ?>